const field = 'mt-1 w-full rounded-md border border-line bg-white px-3 py-2 text-[15px] placeholder:text-muted/60 focus:border-accent focus:outline-none';

export default function IcpForm({ icp, onChange, disabled }) {
  const set = (k) => (e) => onChange({ ...icp, [k]: e.target.value });
  return (
    <fieldset disabled={disabled} className="space-y-4">
      <legend className="text-lg font-semibold">Who is your ideal customer?</legend>
      <p className="-mt-2 text-sm text-muted">Every lead is scored against this. Separate multiple values with commas.</p>
      <label className="block text-sm font-medium">Industries
        <input className={field} value={icp.industries} onChange={set('industries')} placeholder="SaaS, Software" />
      </label>
      <label className="block text-sm font-medium">Job titles you want to reach
        <input className={field} value={icp.titles} onChange={set('titles')} placeholder="VP of Sales, Head of Growth, Founder" />
      </label>
      <div className="grid grid-cols-2 gap-3">
        <label className="block text-sm font-medium">Employees, min
          <input className={`${field} num`} inputMode="numeric" value={icp.employeeMin} onChange={set('employeeMin')} placeholder="50" />
        </label>
        <label className="block text-sm font-medium">Employees, max
          <input className={`${field} num`} inputMode="numeric" value={icp.employeeMax} onChange={set('employeeMax')} placeholder="1000" />
        </label>
      </div>
      <label className="block text-sm font-medium">Regions
        <input className={field} value={icp.regions} onChange={set('regions')} placeholder="US, Canada" />
      </label>
    </fieldset>
  );
}
