import { useRef, useState } from 'react';

export default function UploadZone({ file, onFile, onSample, busy }) {
  const input = useRef(null);
  const [over, setOver] = useState(false);

  async function take(f) {
    if (!f) return;
    onFile({ name: f.name, csv: await f.text(), size: f.size });
  }

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); take(e.dataTransfer.files?.[0]); }}
        className={`rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors ${over ? 'border-accent bg-white' : 'border-line bg-white/60'}`}
      >
        {file ? (
          <>
            <p className="text-lg font-semibold break-all">{file.name}</p>
            <p className="mt-1 text-sm text-muted num">{(file.size / 1024).toFixed(0)} KB · {file.csv.split('\n').length - 1} lines</p>
          </>
        ) : (
          <>
            <p className="text-lg font-semibold">Drop a CSV of leads here</p>
            <p className="mt-1 text-sm text-muted">Any column names work. We look for company, website, name, title, email, industry, size and location.</p>
          </>
        )}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button type="button" disabled={busy} onClick={() => input.current?.click()}
            className="rounded-md border border-line bg-white px-4 py-2 text-sm font-medium hover:border-ink disabled:opacity-50">
            {file ? 'Choose a different file' : 'Choose file'}
          </button>
          <button type="button" disabled={busy} onClick={onSample}
            className="rounded-md px-3 py-2 text-sm font-medium text-accent-ink underline underline-offset-4 hover:text-accent disabled:opacity-50">
            Try the sample list
          </button>
        </div>
        <input ref={input} type="file" accept=".csv,text/csv" className="sr-only" onChange={(e) => take(e.target.files?.[0])} />
      </div>
    </div>
  );
}
