const TIER = {
  hot: { bar: 'bg-hot', text: 'text-accent-ink', label: 'Hot' },
  warm: { bar: 'bg-warm', text: 'text-warm-ink', label: 'Warm' },
  cold: { bar: 'bg-cold', text: 'text-muted', label: 'Cold' },
};

export function emailStatus(l) {
  if (!l.email) return { text: 'No email', cls: 'text-muted' };
  if (l.email_valid === false) return { text: 'Invalid email', cls: 'text-bad' };
  if (l.flags.includes('role_address')) return { text: 'Shared inbox', cls: 'text-warm-ink' };
  return { text: 'Email looks good', cls: 'text-muted' };
}

export function ScoreBar({ lead, big = false }) {
  const t = TIER[lead.tier] ?? TIER.cold;
  return (
    <div className="flex items-center gap-3">
      <span className={`num font-bold ${big ? 'text-4xl' : 'w-8 text-right text-lg'}`}>{lead.score ?? '–'}</span>
      <div className={`${big ? 'h-2.5 w-40' : 'h-2 w-20'} overflow-hidden rounded-full bg-paper`} aria-hidden>
        <div className={`h-full ${t.bar}`} style={{ width: `${lead.score ?? 0}%` }} />
      </div>
      {big && <span className={`text-sm font-semibold ${t.text}`}>{t.label}</span>}
    </div>
  );
}

export default function LeadTable({ leads, selectedId, onSelect }) {
  if (!leads.length) {
    return <p className="rounded-xl border border-line bg-white p-8 text-center text-muted">No leads match these filters. Clear the search or pick another tier.</p>;
  }
  return (
    <div className="overflow-x-auto rounded-xl border border-line bg-white">
      <table className="w-full min-w-[760px] text-left text-[15px]">
        <thead className="border-b border-line text-sm text-muted">
          <tr>
            <th className="px-4 py-3 font-medium">Score</th>
            <th className="px-4 py-3 font-medium">Lead</th>
            <th className="px-4 py-3 font-medium">Company</th>
            <th className="px-4 py-3 font-medium">Why this score</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((l) => {
            const e = emailStatus(l);
            return (
              <tr key={l.id} tabIndex={0} aria-selected={selectedId === l.id}
                onClick={() => onSelect(l)} onKeyDown={(ev) => (ev.key === 'Enter' || ev.key === ' ') && (ev.preventDefault(), onSelect(l))}
                className={`cursor-pointer border-b border-line/70 align-top last:border-0 hover:bg-paper/70 ${selectedId === l.id ? 'bg-paper' : ''}`}>
                <td className="px-4 py-3.5"><ScoreBar lead={l} /></td>
                <td className="px-4 py-3.5">
                  <div className="font-semibold">{l.contact_name || 'Unnamed contact'}</div>
                  <div className="text-sm text-muted">{l.title || 'No title'}</div>
                  <div className={`text-sm ${e.cls}`}>{e.text}</div>
                </td>
                <td className="px-4 py-3.5">
                  <div className="font-medium">{l.company || l.domain}</div>
                  <div className="text-sm text-muted num">
                    {[l.industry, l.employee_count && `${l.employee_count.toLocaleString()} staff`, l.location].filter(Boolean).join(', ') || 'No company details'}
                  </div>
                </td>
                <td className="max-w-xs px-4 py-3.5 text-sm text-muted">{l.score_reason}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
