import { useEffect, useRef, useState } from 'react';
import { ScoreBar, emailStatus } from './LeadTable.jsx';

const FLAG_TEXT = {
  bad_email_format: 'Email address is malformed', role_address: 'Shared inbox, not a person', free_email_provider: 'Personal email provider',
  no_email: 'No email on file', no_domain: 'No website on file', bad_domain_format: 'Website address is malformed',
  domain_does_not_resolve: 'Website domain does not resolve', email_domain_has_no_mx: 'Email domain cannot receive mail',
};

export default function LeadPanel({ lead, onClose }) {
  const closeBtn = useRef(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    closeBtn.current?.focus();
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  useEffect(() => setCopied(false), [lead.id]);

  async function copy() {
    try { await navigator.clipboard.writeText(lead.outreach_angle); setCopied(true); setTimeout(() => setCopied(false), 1800); } catch { /* clipboard blocked */ }
  }

  const rows = [
    ['Email', lead.email || 'None'], ['Phone', lead.phone || 'None'], ['Website', lead.domain || 'None'],
    ['Industry', lead.industry || 'Unknown'], ['Employees', lead.employee_count?.toLocaleString() ?? 'Unknown'], ['Location', lead.location || 'Unknown'],
  ];
  const issues = lead.flags.filter((f) => FLAG_TEXT[f]);

  return (
    <div className="fixed inset-0 z-20 flex justify-end bg-ink/30" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label={`Details for ${lead.contact_name || lead.company}`}
        onClick={(e) => e.stopPropagation()} className="panel-in h-full w-full max-w-md overflow-y-auto bg-white p-6 shadow-xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold">{lead.contact_name || 'Unnamed contact'}</h2>
            <p className="text-muted">{[lead.title, lead.company].filter(Boolean).join(' at ')}</p>
          </div>
          <button ref={closeBtn} onClick={onClose} className="rounded-md border border-line px-3 py-1.5 text-sm font-medium hover:border-ink">Close</button>
        </div>

        <div className="mt-5"><ScoreBar lead={lead} big /></div>
        <p className="mt-3 text-[15px]">{lead.score_reason}</p>

        <h3 className="mt-6 text-sm font-semibold text-muted">Suggested opener</h3>
        <blockquote className="mt-1 rounded-lg border-l-4 border-accent bg-paper p-3 text-[15px]">{lead.outreach_angle}</blockquote>
        <button onClick={copy} className="mt-2 rounded-md bg-accent px-3.5 py-2 text-sm font-semibold text-white hover:bg-accent-ink">
          {copied ? 'Copied' : 'Copy opener'}
        </button>
        <p className="mt-1 text-xs text-muted" aria-live="polite">{lead.scored_by === 'claude' ? 'Written by Claude.' : 'Written from built-in templates.'}</p>

        <h3 className="mt-6 text-sm font-semibold text-muted">Details</h3>
        <dl className="mt-1 divide-y divide-line/70 text-[15px]">
          {rows.map(([k, v]) => (
            <div key={k} className="flex justify-between gap-4 py-2"><dt className="text-muted">{k}</dt><dd className="break-all text-right num">{v}</dd></div>
          ))}
          <div className="flex justify-between gap-4 py-2"><dt className="text-muted">Email check</dt><dd className={emailStatus(lead).cls}>{emailStatus(lead).text}</dd></div>
        </dl>
        {issues.length > 0 && (
          <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-warm-ink">{issues.map((f) => <li key={f}>{FLAG_TEXT[f]}</li>)}</ul>
        )}
      </aside>
    </div>
  );
}
