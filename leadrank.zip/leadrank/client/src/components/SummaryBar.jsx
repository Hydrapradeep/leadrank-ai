const pct = (n, t) => (t ? `${(n / t) * 100}%` : '0%');

export default function SummaryBar({ s }) {
  const tiers = [
    { k: 'hot', label: 'Hot', n: s.hot, bg: 'bg-hot' },
    { k: 'warm', label: 'Warm', n: s.warm, bg: 'bg-warm' },
    { k: 'cold', label: 'Cold', n: s.cold, bg: 'bg-cold' },
  ];
  return (
    <section aria-label="Upload summary" className="rounded-xl border border-line bg-white p-5">
      <p className="text-[15px] text-muted num">
        <span className="font-semibold text-ink">{s.total}</span> rows uploaded, <span className="font-semibold text-ink">{s.duplicates}</span> duplicates
        removed, <span className="font-semibold text-ink">{s.unique}</span> unique leads ranked.
        {' '}{s.invalid_email > 0 && <><span className="font-semibold text-bad">{s.invalid_email}</span> have an invalid email. </>}
        {s.role_address > 0 && <><span className="font-semibold text-ink">{s.role_address}</span> use a shared inbox like info@.</>}
      </p>
      <div className="bar-grow mt-4 flex h-3 w-full overflow-hidden rounded-full bg-paper" role="img"
        aria-label={`${s.hot} hot, ${s.warm} warm, ${s.cold} cold`}>
        {tiers.map((t) => (
          <div key={t.k} className={t.bg} style={{ width: pct(t.n, s.unique) }} />
        ))}
      </div>
      <dl className="mt-3 flex flex-wrap gap-x-8 gap-y-2">
        {tiers.map((t) => (
          <div key={t.k} className="flex items-baseline gap-2">
            <span className={`inline-block h-2.5 w-2.5 rounded-full ${t.bg}`} aria-hidden />
            <dt className="text-sm text-muted">{t.label}</dt>
            <dd className="text-2xl font-bold num">{t.n}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
