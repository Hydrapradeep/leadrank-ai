import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api.js';
import UploadZone from './components/UploadZone.jsx';
import IcpForm from './components/IcpForm.jsx';
import SummaryBar from './components/SummaryBar.jsx';
import LeadTable from './components/LeadTable.jsx';
import LeadPanel from './components/LeadPanel.jsx';

const EMPTY_ICP = { industries: '', titles: '', employeeMin: '', employeeMax: '', regions: '' };
const EXAMPLE_ICP = { industries: 'SaaS, Software', titles: 'VP of Sales, Head of Growth, Founder, CEO', employeeMin: '50', employeeMax: '1000', regions: 'US, Canada' };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default function App() {
  const [view, setView] = useState('setup');
  const [config, setConfig] = useState(null);
  const [file, setFile] = useState(null);
  const [icp, setIcp] = useState(EMPTY_ICP);
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api.config().then(setConfig).catch(() => setError("Can't reach the LeadRank API. Start the server and refresh.")); }, []);

  async function useSample() {
    setError('');
    try { setFile({ name: 'sample_leads.csv', csv: await api.sample(), size: 0 }); setIcp(EXAMPLE_ICP); }
    catch (e) { setError(e.message); }
  }
  const sampleLines = (f) => ({ ...f, size: new Blob([f.csv]).size });

  async function run() {
    setError('');
    setView('processing');
    try {
      const up = await api.upload(file.name, file.csv);
      setSummary(up.summary);
      await api.score(up.summary.uploadId, icp);
      for (;;) {
        await sleep(600);
        const s = await api.summary(up.summary.uploadId);
        setSummary(s);
        if (s.status === 'failed') throw new Error('Scoring failed on the server. Check the server logs.');
        if (s.status === 'done') break;
      }
      setView('results');
    } catch (e) { setError(e.message); setView('setup'); }
  }

  return (
    <div className="mx-auto max-w-6xl px-5 pb-16">
      <header className="flex items-center justify-between py-6">
        <button onClick={() => { setView('setup'); setSummary(null); }} className="text-xl font-bold tracking-tight">LeadRank</button>
        {config && <span className="text-sm text-muted">{config.scorer === 'claude' ? 'Scoring with Claude' : 'Scoring with built-in rules'}</span>}
      </header>

      {error && <p role="alert" className="mb-5 rounded-lg border border-bad/30 bg-white px-4 py-3 text-[15px] text-bad">{error}</p>}

      {view === 'setup' && (
        <main>
          <h1 className="max-w-2xl text-4xl font-bold leading-tight tracking-tight">Know which leads to call first.</h1>
          <p className="mt-3 max-w-xl text-lg text-muted">Upload a lead list. LeadRank cleans it, removes duplicates, scores every lead against your ideal customer, and gives your reps a first line to open with.</p>
          <div className="mt-8 grid gap-8 lg:grid-cols-2">
            <UploadZone file={file && sampleLines(file)} onFile={setFile} onSample={useSample} />
            <IcpForm icp={icp} onChange={setIcp} />
          </div>
          <div className="mt-8 flex items-center gap-4">
            <button disabled={!file} onClick={run} className="rounded-md bg-accent px-6 py-3 text-base font-semibold text-white hover:bg-accent-ink disabled:cursor-not-allowed disabled:opacity-40">Rank my leads</button>
            {!file && <span className="text-sm text-muted">Add a CSV to continue.</span>}
          </div>
        </main>
      )}

      {view === 'processing' && <Processing s={summary} />}
      {view === 'results' && summary && <Results summary={summary} config={config} onNew={() => { setView('setup'); setSummary(null); }} />}
    </div>
  );
}

function Processing({ s }) {
  const done = s?.target ? Math.round((s.scored / s.target) * 100) : 0;
  return (
    <main className="max-w-xl pt-10" aria-live="polite">
      <h1 className="text-3xl font-bold tracking-tight">{s ? 'Scoring your leads' : 'Reading your file'}</h1>
      {s && <p className="mt-2 text-muted num">{s.total} rows read, {s.duplicates} duplicates removed, {s.invalid_email} invalid emails flagged.</p>}
      <div className="mt-6 h-3 overflow-hidden rounded-full bg-white" role="progressbar" aria-valuenow={done} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full bg-accent transition-[width] duration-500" style={{ width: `${s ? Math.max(done, 4) : 4}%` }} />
      </div>
      {s?.target > 0 && <p className="mt-2 text-sm text-muted num">{s.scored} of {s.target} scored</p>}
    </main>
  );
}

function Results({ summary, config, onNew }) {
  const [leads, setLeads] = useState([]);
  const [tier, setTier] = useState('');
  const [q, setQ] = useState('');
  const [debounced, setDebounced] = useState('');
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState('');
  const id = summary.uploadId;

  useEffect(() => { const t = setTimeout(() => setDebounced(q), 250); return () => clearTimeout(t); }, [q]);
  useEffect(() => {
    let live = true;
    api.leads({ upload: id, tier, q: debounced }).then((r) => live && setLeads(r.leads)).catch((e) => live && setError(e.message));
    return () => { live = false; };
  }, [id, tier, debounced]);
  const close = useCallback(() => setSelected(null), []);

  const chips = [['', 'All', summary.unique], ['hot', 'Hot', summary.hot], ['warm', 'Warm', summary.warm], ['cold', 'Cold', summary.cold]];
  const exportBtn = 'rounded-md border border-line bg-white px-3.5 py-2 text-sm font-medium hover:border-ink';

  return (
    <main className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Ranked leads</h1>
          <p className="text-muted">{summary.filename}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <a className={exportBtn} href={api.exportUrl(id, { tier })}>Download CSV</a>
          <a className={exportBtn} href={api.exportUrl(id, { tier, format: 'hubspot' })}>Download for HubSpot</a>
          <button className={exportBtn} onClick={onNew}>Upload another list</button>
        </div>
      </div>

      {summary.scorer !== 'claude' && (
        <p className="rounded-lg border border-line bg-white px-4 py-3 text-sm text-muted">
          These scores come from built-in rules. Add an Anthropic API key on the server to have Claude score each lead and write a more specific opener.
        </p>
      )}

      <SummaryBar s={summary} />

      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1.5" role="group" aria-label="Filter by tier">
          {chips.map(([k, label, n]) => (
            <button key={label} onClick={() => setTier(k)} aria-pressed={tier === k}
              className={`rounded-full border px-3.5 py-1.5 text-sm font-medium num ${tier === k ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink'}`}>
              {label} {n}
            </button>
          ))}
        </div>
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search company, name, title or industry"
          aria-label="Search leads" className="min-w-64 flex-1 rounded-md border border-line bg-white px-3 py-2 text-[15px] focus:border-accent focus:outline-none" />
      </div>

      {error && <p role="alert" className="text-bad">{error}</p>}
      <LeadTable leads={leads} selectedId={selected?.id} onSelect={setSelected} />
      {selected && <LeadPanel lead={selected} onClose={close} />}
    </main>
  );
}
