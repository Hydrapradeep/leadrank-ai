const base = import.meta.env.VITE_API_URL ?? '';

async function req(path, opts = {}) {
  const res = await fetch(base + path, { headers: { 'content-type': 'application/json' }, ...opts });
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try { msg = (await res.json()).error || msg; } catch { /* keep default */ }
    throw new Error(msg);
  }
  return res.json();
}

const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== '' && v != null)).toString();

export const api = {
  config: () => req('/api/config'),
  sample: async () => {
    const r = await fetch(base + '/api/sample');
    if (!r.ok) throw new Error('Sample data is not available on this server.');
    return r.text();
  },
  upload: (filename, csv) => req('/api/uploads', { method: 'POST', body: JSON.stringify({ filename, csv }) }),
  score: (id, icp) => req(`/api/uploads/${id}/score`, { method: 'POST', body: JSON.stringify({ icp }) }),
  summary: (id) => req(`/api/uploads/${id}/summary`),
  leads: (params) => req(`/api/leads?${qs(params)}`),
  exportUrl: (id, extra = {}) => `${base}/api/uploads/${id}/export.csv?${qs(extra)}`,
};
