# LeadRank

**Know which leads to call first.** LeadRank takes a raw lead list (for example a SaaSquatch export), cleans it, removes duplicates, scores every lead against your ideal customer profile (ICP), and gives each lead a one-line opener a rep can use. The result is a ranked, filterable list you can export to a CRM.

## The problem it solves

Lead-finding tools such as SaaSquatch are good at producing volume. The bottleneck for a sales team is what comes next: lists contain duplicates, bad and shared-inbox emails, and a lot of companies that were never a fit. Reps burn time on the wrong rows. LeadRank sits after the list is built and answers one question: *who should we contact first, and what do we say?*

## What it does

1. **Ingest.** Upload any CSV. Headers are mapped flexibly (`Company Name`, `Organization`, `Account` all work). Websites are normalized to bare domains, and employee counts like `51-200` or `1,200` become numbers.
2. **Validate.** Email format, shared inboxes (`info@`, `sales@`), personal providers, and domain format. Optional live DNS/MX checks.
3. **Deduplicate.** Duplicates are found by valid email, then by domain plus person. The most complete row in each group is kept.
4. **Score (0-100).** Weights: industry 30, company size 25, title/seniority 25, data quality 10, region 10. Tiers: hot 75+, warm 50-74, cold below 50.
5. **Explain and act.** Each lead gets a short reason and a suggested opener. Filter by tier, search, open a lead for details, and export as plain CSV or a HubSpot-import-ready CSV.

## Architecture

| Layer | Choice |
|---|---|
| Frontend | React 18, Vite, Tailwind CSS 4 (static build) |
| Backend | Node 20+, Express |
| Database | PostgreSQL. `DATABASE_URL` for a hosted database (Neon, Supabase, Render). With no `DATABASE_URL` it runs on embedded Postgres (PGlite), so `npm start` works with zero setup |
| Scoring | Claude API (`ANTHROPIC_API_KEY`), batched 10 leads per call, 3 calls in flight. Rule-based fallback scorer when no key is set or a call fails |
| Cache | Postgres table `score_cache`, keyed by a hash of the lead's scoring-relevant fields plus the ICP. Re-scoring unchanged leads makes no API calls |
| Hosting | Frontend as a static site on Vercel, backend as an always-on web service on Render |
| Deploy | Push to GitHub; both platforms build and deploy automatically |

```
CSV --> parse/normalize --> validate --> dedupe --> store (Postgres)
                                                     |
                      ICP --> batch (10) --> cache hit? --> Claude / fallback scorer
                                                     |
                                     ranked leads + reasons + openers --> UI / CSV export
```

Scoring runs as a background job on the server and the UI polls `/summary` for progress, so large lists don't block a request.

## Run it locally

```bash
npm run install:all
cp server/.env.example server/.env      # optional; add ANTHROPIC_API_KEY for Claude scoring
npm run dev:server                      # API on :4000
npm run dev:client                      # UI on :5173 (proxies /api to :4000)
```

Click **Try the sample list** to load `data/sample_leads.csv` (204 synthetic rows with duplicates, malformed emails and shared inboxes) with an example ICP.

Single-process mode: `npm run build && npm start` serves the UI and API together on :4000.

Tests: `npm test` runs parsing, validation, dedupe, scoring and an end-to-end upload/score/export flow.

## Deploy

**Backend (Render web service)**
- Build: `npm --prefix server install`, start: `node server/src/index.js`
- Env: `DATABASE_URL`, `ANTHROPIC_API_KEY`, `VALIDATE_DNS=true`

**Frontend (Vercel)**
- Root directory `client`, build `npm run build`, output `dist`
- Env: `VITE_API_URL=https://<your-render-service>.onrender.com`

(Or deploy everything to Render only: build `npm run install:all && npm run build`, start `npm start`.)

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/icp` | Save an ideal customer profile |
| POST | `/api/uploads` | `{filename, csv}`: parse, validate, dedupe, store |
| POST | `/api/uploads/:id/score` | `{icp}` or `{icpId}`: start scoring (202, runs in background) |
| GET | `/api/uploads/:id/summary` | Counts, progress, scorer used |
| GET | `/api/leads?upload=&tier=&minScore=&q=` | Ranked, filtered leads |
| GET | `/api/uploads/:id/export.csv?format=hubspot` | Export |

## Design decisions

- **Rank, don't just find.** The scoring weights mirror how a sales manager triages a list, and every score carries a reason so reps can trust or override it.
- **Data hygiene is part of the product.** Shared inboxes and invalid emails lower the score and are called out, because a perfect-fit lead with a dead email isn't actionable.
- **Honest degradation.** If Claude isn't configured or a batch fails, the rule-based scorer fills in and the UI says so. Fallback results are never cached as Claude results.
- **Untrusted input.** Uploaded fields are treated as data in the prompt, and exported cells are escaped against spreadsheet formula injection.
- **Cost control.** Batching cuts API calls roughly 10x, and the cache removes repeat scoring.

## Limitations and next steps

- Data is whatever you upload; there's no live enrichment (company size, funding, tech stack) yet. A natural next step is an enrichment provider behind the same pipeline.
- No auth or multi-user workspaces; uploads are not private to a user.
- Scoring is only as good as the ICP you describe. Learning weights from won/lost deals would be the next improvement.
- The synthetic sample uses fake domains, so live DNS checks are off by default (`VALIDATE_DNS=false`).
- Intended for lead data you are allowed to use. Respect applicable privacy and outreach rules (for example GDPR, CAN-SPAM).
