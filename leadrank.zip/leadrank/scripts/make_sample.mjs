// Generates data/sample_leads.csv: synthetic leads with deliberate duplicates, bad emails and role addresses.
import fs from 'node:fs';
import { stringify } from '../server/node_modules/csv-stringify/dist/esm/sync.js';

let seed = 42;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
const pick = (a) => a[Math.floor(rnd() * a.length)];

const pre = ['North', 'Blue', 'Iron', 'Bright', 'Summit', 'Cedar', 'Nimbus', 'Atlas', 'Harbor', 'Vertex', 'Pioneer', 'Lumen', 'Granite', 'Orbit', 'Maple', 'Falcon', 'Quartz', 'Meridian', 'Keystone', 'Ember'];
const suf = ['Systems', 'Works', 'Labs', 'Logistics', 'Health', 'Partners', 'Software', 'Dynamics', 'Group', 'Industries', 'Analytics', 'Cloud', 'Supply', 'Financial', 'Builders'];
const industries = ['SaaS', 'Software', 'Manufacturing', 'Logistics', 'Healthcare', 'Financial Services', 'Retail', 'Education', 'Construction', 'Staffing'];
const sizes = ['1-10', '11-50', '51-200', '201-500', '501-1000', '1001-5000', '85', '240', '1,200', '35'];
const titles = ['CEO', 'Founder', 'VP of Sales', 'Head of Growth', 'Director of Operations', 'Sales Manager', 'Marketing Manager', 'CTO', 'Operations Manager', 'Account Executive', 'Software Engineer', 'HR Coordinator', 'Chief Revenue Officer', 'Director of Business Development', 'Office Administrator'];
const places = ['Austin, TX', 'Boston, MA', 'Chicago, IL', 'Denver, CO', 'Seattle, WA', 'Atlanta, GA', 'Toronto, Canada', 'London, UK', 'Berlin, Germany', 'Bengaluru, India', 'Miami, FL', 'New York, NY'];
const first = ['Maya', 'Liam', 'Priya', 'Noah', 'Sofia', 'Ethan', 'Aisha', 'Lucas', 'Chen', 'Olivia', 'Mateo', 'Hana', 'Daniel', 'Zoe', 'Ravi', 'Emma', 'Omar', 'Grace', 'Felix', 'Nora'];
const last = ['Patel', 'Nguyen', 'Garcia', 'Kim', 'Johnson', 'Schmidt', 'Okafor', 'Rossi', 'Silva', 'Brown', 'Tanaka', 'Khan', 'Murphy', 'Costa', 'Lee'];

const rows = [];
const used = new Set();
while (rows.length < 190) {
  const company = `${pick(pre)} ${pick(suf)}`;
  if (used.has(company)) continue;
  used.add(company);
  const slug = company.toLowerCase().replace(/\s+/g, '');
  const domain = `${slug}.com`;
  const fn = pick(first), ln = pick(last);
  let email = `${fn}.${ln}@${domain}`.toLowerCase();
  const r = rnd();
  if (r < 0.04) email = `${fn.toLowerCase()}${ln.toLowerCase()}.${domain}`;      // missing @
  else if (r < 0.07) email = `${fn.toLowerCase()}@@${domain}`;                   // double @
  else if (r < 0.14) email = `${pick(['info', 'sales', 'contact', 'support'])}@${domain}`; // role address
  else if (r < 0.17) email = '';                                                  // blank
  rows.push({
    'Company Name': company,
    'Website': pick([`https://www.${domain}`, `www.${domain}`, domain, `https://${domain}/about`]),
    'First Name': fn, 'Last Name': ln,
    'Job Title': pick(titles),
    'Email': email,
    'Phone': rnd() < 0.7 ? `+1 555 ${String(Math.floor(rnd() * 900) + 100)} ${String(Math.floor(rnd() * 9000) + 1000)}` : '',
    'Industry': rnd() < 0.9 ? pick(industries) : '',
    'Employees': pick(sizes),
    'Location': rnd() < 0.92 ? pick(places) : '',
  });
}
// duplicates: same email, different case/less data; same person via different domain format
for (let i = 0; i < 14; i++) {
  const src = rows[Math.floor(rnd() * 150)];
  const d = { ...src, Email: src.Email.toUpperCase() };
  if (i % 2) { d.Phone = ''; d.Industry = ''; }
  rows.splice(Math.floor(rnd() * rows.length), 0, d);
}
fs.writeFileSync(new URL('../data/sample_leads.csv', import.meta.url), stringify(rows, { header: true }));
console.log(`wrote ${rows.length} rows`);
