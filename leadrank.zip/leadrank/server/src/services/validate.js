import dns from 'node:dns/promises';

const EMAIL_RE = /^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)+$/i;
const DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9-]+\.)+[a-z]{2,}$/i;
const ROLE_LOCALS = new Set(['info', 'sales', 'support', 'contact', 'hello', 'admin', 'office', 'team', 'mail', 'enquiries', 'help', 'noreply', 'no-reply']);
const FREE_PROVIDERS = new Set(['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com', 'icloud.com', 'proton.me', 'protonmail.com']);

const dnsCache = new Map();
const withTimeout = (p, ms) =>
  Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);

async function domainResolves(domain) {
  if (dnsCache.has(domain)) return dnsCache.get(domain);
  let ok = false;
  try {
    const mx = await withTimeout(dns.resolveMx(domain), 3000);
    ok = mx.length > 0;
  } catch {
    try {
      const a = await withTimeout(dns.resolve4(domain), 3000);
      ok = a.length > 0;
    } catch { ok = false; }
  }
  dnsCache.set(domain, ok);
  return ok;
}

export async function validateLead(lead, { dnsCheck = process.env.VALIDATE_DNS === 'true' } = {}) {
  const flags = [];
  const email = lead.email;
  let email_valid = null;
  if (email) {
    email_valid = EMAIL_RE.test(email);
    if (!email_valid) flags.push('bad_email_format');
    else {
      const [local, host] = email.split('@');
      if (ROLE_LOCALS.has(local)) flags.push('role_address');
      if (FREE_PROVIDERS.has(host)) flags.push('free_email_provider');
    }
  } else flags.push('no_email');

  let domain_valid = null;
  if (lead.domain) {
    domain_valid = DOMAIN_RE.test(lead.domain);
    if (!domain_valid) flags.push('bad_domain_format');
  } else flags.push('no_domain');

  if (dnsCheck) {
    if (domain_valid) {
      domain_valid = await domainResolves(lead.domain);
      if (!domain_valid) flags.push('domain_does_not_resolve');
    }
    if (email_valid) {
      const host = email.split('@')[1];
      if (!FREE_PROVIDERS.has(host) && !(await domainResolves(host))) {
        email_valid = false;
        flags.push('email_domain_has_no_mx');
      }
    }
  }
  return { email_valid, domain_valid, flags };
}

export async function validateAll(leads, concurrency = 20) {
  const out = new Array(leads.length);
  let i = 0;
  await Promise.all(Array.from({ length: concurrency }, async () => {
    while (i < leads.length) {
      const idx = i++;
      out[idx] = await validateLead(leads[idx]);
    }
  }));
  return out;
}
