import { parse } from 'csv-parse/sync';

const norm = (h) => String(h).toLowerCase().replace(/[^a-z0-9]/g, '');

const ALIASES = {
  company: ['company', 'companyname', 'organization', 'organisation', 'account', 'accountname', 'business'],
  domain: ['domain', 'website', 'companywebsite', 'url', 'companydomain', 'site'],
  contact_name: ['name', 'contact', 'contactname', 'fullname', 'personname', 'leadname'],
  first_name: ['firstname', 'first', 'givenname'],
  last_name: ['lastname', 'last', 'surname', 'familyname'],
  title: ['title', 'jobtitle', 'position', 'role', 'contacttitle'],
  email: ['email', 'emailaddress', 'workemail', 'contactemail'],
  phone: ['phone', 'phonenumber', 'mobile', 'telephone'],
  industry: ['industry', 'sector', 'vertical'],
  employee_count: ['employees', 'employeecount', 'size', 'companysize', 'headcount', 'numberofemployees'],
  location: ['location', 'city', 'country', 'region', 'hq', 'headquarters', 'state'],
};

export function parseEmployees(v) {
  if (v == null) return null;
  const nums = String(v).replace(/,/g, '').match(/\d+(\.\d+)?/g);
  if (!nums) return null;
  const n = nums.map(Number);
  const val = n.length >= 2 ? Math.round((n[0] + n[1]) / 2) : Math.round(n[0]);
  return Number.isFinite(val) ? val : null;
}

export function cleanDomain(v) {
  if (!v) return '';
  let d = String(v).trim().toLowerCase();
  d = d.replace(/^https?:\/\//, '').replace(/^www\./, '');
  return d.split(/[/?#]/)[0].trim();
}

export function parseCsv(text) {
  const records = parse(text, {
    columns: true, skip_empty_lines: true, trim: true, bom: true, relax_column_count: true,
  });
  if (!records.length) throw new Error('The CSV has no data rows.');

  const headers = Object.keys(records[0]);
  const map = {};
  for (const [field, names] of Object.entries(ALIASES)) {
    const found = headers.find((h) => names.includes(norm(h)));
    if (found) map[field] = found;
  }
  if (!map.email && !map.domain && !map.company) {
    throw new Error(`Couldn't find an email, domain or company column. Headers seen: ${headers.join(', ')}`);
  }

  const get = (r, f) => (map[f] ? String(r[map[f]] ?? '').trim() : '');
  const leads = records.map((r) => {
    let contact = get(r, 'contact_name');
    if (!contact) contact = [get(r, 'first_name'), get(r, 'last_name')].filter(Boolean).join(' ');
    const email = get(r, 'email').toLowerCase();
    let domain = cleanDomain(get(r, 'domain'));
    if (!domain && email.includes('@')) domain = email.split('@')[1] ?? '';
    return {
      company: get(r, 'company'), domain, contact_name: contact, title: get(r, 'title'),
      email, phone: get(r, 'phone'), industry: get(r, 'industry'),
      employee_count: parseEmployees(get(r, 'employee_count')), location: get(r, 'location'),
    };
  });
  return { leads, mappedColumns: map, headers };
}
