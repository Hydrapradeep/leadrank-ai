const FIELDS = ['company', 'domain', 'contact_name', 'title', 'email', 'phone', 'industry', 'employee_count', 'location'];
const completeness = (l) => FIELDS.filter((f) => l[f] != null && l[f] !== '').length;

export function dedupeKey(l) {
  if (l.email && l.email_valid !== false) return `e:${l.email}`;
  const person = (l.contact_name || '').toLowerCase().replace(/\s+/g, ' ');
  if (l.domain && person) return `d:${l.domain}|${person}`;
  if (l.domain) return `d:${l.domain}`;
  return `c:${(l.company || '').toLowerCase()}|${person}`;
}

/** Marks duplicates in place; the most complete row in each group is kept. Returns duplicate count. */
export function dedupe(leads) {
  const best = new Map();
  leads.forEach((l, i) => {
    l.dedupe_key = dedupeKey(l);
    const cur = best.get(l.dedupe_key);
    if (cur === undefined || completeness(l) > completeness(leads[cur])) best.set(l.dedupe_key, i);
  });
  leads.forEach((l, i) => { l.is_duplicate = best.get(l.dedupe_key) !== i; });
  return leads.filter((l) => l.is_duplicate).length;
}
