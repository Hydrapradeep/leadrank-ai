import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import cors from 'cors';
import icp from './routes/icp.js';
import uploads from './routes/uploads.js';
import leads from './routes/leads.js';
import { dbKind } from './db/client.js';
import { scorerMode } from './services/score.js';

const here = path.dirname(fileURLToPath(import.meta.url));

export function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '10mb' }));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.get('/api/config', (_req, res) =>
    res.json({ scorer: scorerMode(), database: dbKind(), dnsChecks: process.env.VALIDATE_DNS === 'true' }));
  app.get('/api/sample', (_req, res) => {
    const file = path.resolve(here, '../../data/sample_leads.csv');
    if (!fs.existsSync(file)) return res.status(404).json({ error: 'Sample file not found.' });
    res.type('text/csv').send(fs.readFileSync(file, 'utf8'));
  });
  app.use('/api/icp', icp);
  app.use('/api/uploads', uploads);
  app.use('/api/leads', leads);

  // Optional single-host deploy: serve the built client
  const dist = path.resolve(here, '../../client/dist');
  if (fs.existsSync(dist)) {
    app.use(express.static(dist));
    app.get(/^(?!\/api).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  }

  app.use((err, _req, res, _next) => {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server.' });
  });
  return app;
}
