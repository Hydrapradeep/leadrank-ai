import { Router } from 'express';
import { query } from '../db/client.js';

const list = (v) =>
  (Array.isArray(v) ? v : String(v ?? '').split(','))
    .map((s) => String(s).trim()).filter(Boolean).slice(0, 30);
const num = (v) => (v === '' || v == null || !Number.isFinite(Number(v)) ? null : Math.max(0, Math.round(Number(v))));

export function normalizeIcp(b = {}) {
  const config = {
    industries: list(b.industries), titles: list(b.titles ?? b.target_titles), regions: list(b.regions),
    employeeMin: num(b.employeeMin), employeeMax: num(b.employeeMax),
    notes: String(b.notes ?? '').slice(0, 500),
  };
  if (config.employeeMin != null && config.employeeMax != null && config.employeeMin > config.employeeMax) {
    [config.employeeMin, config.employeeMax] = [config.employeeMax, config.employeeMin];
  }
  return { name: String(b.name || 'My ICP').slice(0, 80), config };
}

export async function saveIcp(body) {
  const { name, config } = normalizeIcp(body);
  const { rows: [r] } = await query('insert into icps (name, config) values ($1,$2) returning id', [name, JSON.stringify(config)]);
  return { id: r.id, name, config };
}

const router = Router();
router.post('/', async (req, res, next) => {
  try { res.status(201).json(await saveIcp(req.body)); } catch (e) { next(e); }
});
export default router;
