import { Router } from 'express';
import { query } from '../db/client.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const upload = Number(req.query.upload);
    if (!upload) return res.status(400).json({ error: 'Missing ?upload=<id>.' });
    const params = [upload]; let where = 'upload_id=$1';
    if (req.query.includeDuplicates !== 'true') where += ' and is_duplicate=false';
    if (req.query.tier) { params.push(String(req.query.tier)); where += ` and tier=$${params.length}`; }
    if (req.query.minScore) { params.push(Number(req.query.minScore) || 0); where += ` and score>=$${params.length}`; }
    if (req.query.q) {
      params.push(`%${String(req.query.q).trim()}%`);
      const p = `$${params.length}`;
      where += ` and (company ilike ${p} or contact_name ilike ${p} or title ilike ${p} or email ilike ${p} or industry ilike ${p})`;
    }
    const limit = Math.min(Number(req.query.limit) || 500, 1000);
    const offset = Number(req.query.offset) || 0;
    const { rows } = await query(
      `select * from leads where ${where} order by score desc nulls last, id limit ${limit} offset ${offset}`, params);
    res.json({
      leads: rows.map((l) => ({ ...l, flags: l.flags ? l.flags.split(',') : [] })),
    });
  } catch (e) { next(e); }
});

export default router;
