import { Router } from 'express';
import { stringify } from 'csv-stringify/sync';
import { query } from '../db/client.js';
import { parseCsv } from '../services/parse.js';
import { validateAll } from '../services/validate.js';
import { dedupe } from '../services/dedupe.js';
import { scoreUpload, scorerMode } from '../services/score.js';
import { saveIcp } from './icp.js';

const MAX_ROWS = 5000;
const router = Router();

const COLS = ['upload_id', 'company', 'domain', 'contact_name', 'title', 'email', 'phone', 'industry',
  'employee_count', 'location', 'email_valid', 'domain_valid', 'flags', 'dedupe_key', 'is_duplicate'];

async function insertLeads(uploadId, leads) {
  for (let i = 0; i < leads.length; i += 100) {
    const chunk = leads.slice(i, i + 100);
    const params = []; const rowsSql = [];
    chunk.forEach((l) => {
      const vals = [uploadId, l.company, l.domain, l.contact_name, l.title, l.email, l.phone, l.industry,
        l.employee_count, l.location, l.email_valid, l.domain_valid, l.flags.join(','), l.dedupe_key, l.is_duplicate];
      rowsSql.push(`(${vals.map((_, j) => `$${params.length + j + 1}`).join(',')})`);
      params.push(...vals);
    });
    await query(`insert into leads (${COLS.join(',')}) values ${rowsSql.join(',')}`, params);
  }
}

export async function getSummary(id) {
  const { rows: [up] } = await query('select * from uploads where id=$1', [id]);
  if (!up) return null;
  const { rows: [c] } = await query(
    `select count(*)::int total,
      (count(*) filter (where is_duplicate))::int duplicates,
      (count(*) filter (where not is_duplicate and email_valid is false))::int invalid_email,
      (count(*) filter (where not is_duplicate and 'role_address' = any(string_to_array(flags, ','))))::int role_address,
      (count(*) filter (where not is_duplicate and tier='hot'))::int hot,
      (count(*) filter (where not is_duplicate and tier='warm'))::int warm,
      (count(*) filter (where not is_duplicate and tier='cold'))::int cold
     from leads where upload_id=$1`, [id]);
  return {
    uploadId: up.id, filename: up.filename, status: up.status, scorer: up.scorer,
    scored: up.scored_count, target: up.score_target, ...c, unique: c.total - c.duplicates,
  };
}

router.post('/', async (req, res, next) => {
  try {
    const { filename, csv } = req.body ?? {};
    if (typeof csv !== 'string' || !csv.trim()) return res.status(400).json({ error: 'Send the CSV text in the "csv" field.' });
    let parsed;
    try { parsed = parseCsv(csv); } catch (e) { return res.status(400).json({ error: e.message }); }
    if (parsed.leads.length > MAX_ROWS) return res.status(413).json({ error: `Too many rows (${parsed.leads.length}). The limit is ${MAX_ROWS}.` });

    const leads = parsed.leads;
    const checks = await validateAll(leads);
    leads.forEach((l, i) => Object.assign(l, checks[i]));
    dedupe(leads);

    const { rows: [up] } = await query('insert into uploads (filename, total_rows) values ($1,$2) returning id', [String(filename || 'leads.csv').slice(0, 200), leads.length]);
    await insertLeads(up.id, leads);
    res.status(201).json({ summary: await getSummary(up.id), mappedColumns: parsed.mappedColumns });
  } catch (e) { next(e); }
});

router.post('/:id/score', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const summary = await getSummary(id);
    if (!summary) return res.status(404).json({ error: 'Upload not found.' });
    if (summary.status === 'scoring') return res.status(409).json({ error: 'This upload is already being scored.' });

    let icpId = req.body?.icpId;
    if (!icpId && req.body?.icp) icpId = (await saveIcp(req.body.icp)).id;
    if (!icpId) return res.status(400).json({ error: 'Send an "icp" object or an "icpId".' });

    await query("update uploads set icp_id=$1, status='scoring', scored_count=0, score_target=$2 where id=$3", [icpId, summary.unique, id]);
    scoreUpload(id); // runs in the background; the client polls /summary
    res.status(202).json({ status: 'scoring', scorer: scorerMode() });
  } catch (e) { next(e); }
});

router.get('/:id/summary', async (req, res, next) => {
  try {
    const s = await getSummary(Number(req.params.id));
    if (!s) return res.status(404).json({ error: 'Upload not found.' });
    res.json(s);
  } catch (e) { next(e); }
});

const safe = (v) => (typeof v === 'string' && /^[=+\-@\t\r]/.test(v) ? `'${v}` : v ?? '');

router.get('/:id/export.csv', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const params = [id]; let where = 'upload_id=$1 and is_duplicate=false';
    if (req.query.tier) { params.push(String(req.query.tier)); where += ` and tier=$${params.length}`; }
    if (req.query.minScore) { params.push(Number(req.query.minScore) || 0); where += ` and score>=$${params.length}`; }
    const { rows } = await query(`select * from leads where ${where} order by score desc nulls last, id`, params);

    let header; let mapRow;
    if (req.query.format === 'hubspot') {
      header = ['Company Name', 'Company Domain Name', 'First Name', 'Last Name', 'Email', 'Job Title', 'Phone Number',
        'Industry', 'Number of Employees', 'City', 'LeadRank Score', 'LeadRank Tier', 'Outreach Angle'];
      mapRow = (l) => {
        const [first, ...rest] = (l.contact_name || '').split(' ');
        return [l.company, l.domain, first, rest.join(' '), l.email, l.title, l.phone, l.industry,
          l.employee_count, l.location, l.score, l.tier, l.outreach_angle];
      };
    } else {
      header = ['rank', 'score', 'tier', 'company', 'contact_name', 'title', 'email', 'phone', 'domain', 'industry',
        'employee_count', 'location', 'reason', 'outreach_angle', 'flags'];
      mapRow = (l, i) => [i + 1, l.score, l.tier, l.company, l.contact_name, l.title, l.email, l.phone, l.domain,
        l.industry, l.employee_count, l.location, l.score_reason, l.outreach_angle, l.flags];
    }
    const out = stringify([header, ...rows.map((l, i) => mapRow(l, i).map(safe))]);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="leadrank-${id}${req.query.format === 'hubspot' ? '-hubspot' : ''}.csv"`);
    res.send(out);
  } catch (e) { next(e); }
});

export default router;
