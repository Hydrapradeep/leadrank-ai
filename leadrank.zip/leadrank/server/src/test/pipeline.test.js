import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

process.env.PGLITE_DIR = 'memory';
delete process.env.ANTHROPIC_API_KEY;
process.env.VALIDATE_DNS = 'false';

const { initDb } = await import('../db/client.js');
const { createApp } = await import('../app.js');
const { parseCsv, parseEmployees, cleanDomain } = await import('../services/parse.js');
const { validateLead } = await import('../services/validate.js');
const { dedupe } = await import('../services/dedupe.js');
const { heuristicScore, tierFor } = await import('../services/score.js');

const sample = fs.readFileSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../data/sample_leads.csv'), 'utf8');

test('parse helpers', () => {
  assert.equal(parseEmployees('51-200'), 126);
  assert.equal(parseEmployees('1,200'), 1200);
  assert.equal(parseEmployees('n/a'), null);
  assert.equal(cleanDomain('https://www.Acme.com/about?x=1'), 'acme.com');
});

test('csv header mapping handles varied headers', () => {
  const { leads } = parseCsv('Organization,Work Email,Job Title,Headcount\nAcme,A@Acme.com,CEO,"1,000"\n');
  assert.equal(leads[0].company, 'Acme');
  assert.equal(leads[0].email, 'a@acme.com');
  assert.equal(leads[0].domain, 'acme.com');
  assert.equal(leads[0].employee_count, 1000);
  assert.throws(() => parseCsv('foo,bar\n1,2\n'), /Couldn't find/);
});

test('validation flags', async () => {
  assert.equal((await validateLead({ email: 'nope.example.com', domain: 'example.com' })).email_valid, false);
  assert.ok((await validateLead({ email: 'info@example.com', domain: 'example.com' })).flags.includes('role_address'));
});

test('dedupe keeps the most complete row', () => {
  const rows = [
    { email: 'a@x.com', email_valid: true, domain: 'x.com', company: 'X' },
    { email: 'a@x.com', email_valid: true, domain: 'x.com', company: 'X', phone: '1', title: 'CEO' },
  ];
  assert.equal(dedupe(rows), 1);
  assert.equal(rows[0].is_duplicate, true);
  assert.equal(rows[1].is_duplicate, false);
});

test('heuristic scoring rewards fit and tiers correctly', () => {
  const icp = { industries: ['SaaS'], employeeMin: 50, employeeMax: 500, titles: ['VP of Sales'], regions: ['US'], notes: '' };
  const good = heuristicScore({ industry: 'SaaS', employee_count: 120, title: 'VP of Sales', location: 'Austin, US', email_valid: true, domain_valid: true, phone: '1', company: 'A', email: 'a@a.com', flags: [] }, icp);
  const bad = heuristicScore({ industry: 'Mining', employee_count: 5, title: 'Intern', location: 'Peru', email_valid: false, flags: [] }, icp);
  assert.ok(good.score >= 75, `good was ${good.score}`);
  assert.ok(bad.score < 40, `bad was ${bad.score}`);
  assert.equal(tierFor(good.score), 'hot');
});

test('end to end: upload, score, filter, export', async () => {
  await initDb();
  const server = createApp().listen(0);
  const base = `http://127.0.0.1:${server.address().port}`;
  const j = (p, o) => fetch(base + p, { headers: { 'content-type': 'application/json' }, ...o }).then((r) => r.json());
  try {
    const up = await j('/api/uploads', { method: 'POST', body: JSON.stringify({ filename: 'sample.csv', csv: sample }) });
    const s = up.summary;
    assert.equal(s.total, 204);
    assert.ok(s.duplicates >= 10, `duplicates ${s.duplicates}`);
    assert.ok(s.invalid_email > 0);

    const r = await fetch(`${base}/api/uploads/${s.uploadId}/score`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ icp: { industries: 'SaaS, Software', employeeMin: 50, employeeMax: 1000, titles: 'VP of Sales, Head of Growth, CEO, Founder', regions: 'US, Canada' } }),
    });
    assert.equal(r.status, 202);

    let sum;
    for (let i = 0; i < 100; i++) {
      sum = await j(`/api/uploads/${s.uploadId}/summary`);
      if (sum.status === 'done') break;
      await new Promise((x) => setTimeout(x, 100));
    }
    assert.equal(sum.status, 'done');
    assert.equal(sum.scorer, 'heuristic');
    assert.equal(sum.hot + sum.warm + sum.cold, sum.unique);

    const { leads } = await j(`/api/leads?upload=${s.uploadId}`);
    assert.equal(leads.length, sum.unique);
    for (let i = 1; i < leads.length; i++) assert.ok(leads[i - 1].score >= leads[i].score);

    const hot = await j(`/api/leads?upload=${s.uploadId}&tier=hot`);
    assert.ok(hot.leads.every((l) => l.tier === 'hot'));

    const csv = await fetch(`${base}/api/uploads/${s.uploadId}/export.csv`).then((x) => x.text());
    assert.equal(csv.split('\n')[0].startsWith('rank,score,tier'), true);
    const hs = await fetch(`${base}/api/uploads/${s.uploadId}/export.csv?format=hubspot`).then((x) => x.text());
    assert.ok(hs.startsWith('Company Name,Company Domain Name'));

    // rescoring the same data should hit the cache and finish fine
    const again = await fetch(`${base}/api/uploads/${s.uploadId}/score`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ icpId: 1 }) });
    assert.equal(again.status, 202);
  } finally { server.close(); }
});
