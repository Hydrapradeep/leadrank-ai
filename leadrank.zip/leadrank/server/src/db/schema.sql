create table if not exists icps (
  id serial primary key,
  name text not null,
  config jsonb not null,
  created_at timestamptz default now()
);

create table if not exists uploads (
  id serial primary key,
  filename text,
  icp_id int,
  status text default 'ingested',
  total_rows int default 0,
  scored_count int default 0,
  score_target int default 0,
  scorer text,
  created_at timestamptz default now()
);

create table if not exists leads (
  id serial primary key,
  upload_id int not null,
  company text, domain text, contact_name text, title text,
  email text, phone text, industry text, employee_count int, location text,
  email_valid boolean, domain_valid boolean, flags text default '',
  dedupe_key text,
  is_duplicate boolean default false,
  score int, tier text, score_reason text, outreach_angle text, scored_by text,
  created_at timestamptz default now()
);
create index if not exists leads_dedupe_idx on leads (dedupe_key);
create index if not exists leads_upload_idx on leads (upload_id, score desc);

create table if not exists score_cache (
  cache_key text primary key,
  result jsonb not null,
  created_at timestamptz default now()
);
