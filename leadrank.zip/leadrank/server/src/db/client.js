import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
let impl;

export async function initDb() {
  const schema = fs.readFileSync(path.join(here, 'schema.sql'), 'utf8');
  if (process.env.DATABASE_URL) {
    const { default: pg } = await import('pg');
    const local = /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL);
    const pool = new pg.Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: local ? false : { rejectUnauthorized: false },
    });
    await pool.query(schema);
    impl = { kind: 'postgres', query: (t, p) => pool.query(t, p) };
  } else {
    const { PGlite } = await import('@electric-sql/pglite');
    const dir = process.env.PGLITE_DIR ?? path.resolve(here, '../../.pgdata');
    const db = dir === 'memory' ? new PGlite() : new PGlite(dir);
    await db.exec(schema);
    impl = { kind: 'embedded postgres (PGlite)', query: (t, p) => db.query(t, p) };
  }
  return impl.kind;
}

export const query = (text, params = []) => impl.query(text, params);
export const dbKind = () => impl?.kind;
