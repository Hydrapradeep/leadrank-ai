import { initDb } from './db/client.js';
import { createApp } from './app.js';

const kind = await initDb();
const port = process.env.PORT || 4000;
createApp().listen(port, () => {
  console.log(`LeadRank API on :${port} | database: ${kind} | scorer: ${process.env.ANTHROPIC_API_KEY ? 'claude' : 'rule-based fallback (no ANTHROPIC_API_KEY)'}`);
});
